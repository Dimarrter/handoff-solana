# HandOff

A receipt for the version you sent. English Solana devnet MVP for project handovers.

## Run

Node.js 20 or newer.

```sh
npm ci
npm test
npm run build
npm start
```

Open http://127.0.0.1:4173. Deploy `dist/` to any static HTTPS host for a public preview. The server binds only to local loopback. No server receives file contents.

## Use

1. Choose a file or load the sample. The browser computes its SHA-256 digest.
2. Download a local JSON receipt, or connect a compatible injected Solana wallet and anchor the digest on devnet first.
3. Share the file and receipt. The reviewer loads both in Verify a handover.
4. HandOff compares the bytes. For an anchored receipt it independently checks the successful transaction, exact memo and signing wallet through devnet RPC.

The wallet needs free devnet SOL. Test SOL has no monetary value. Mainnet funds and transfers are outside this MVP. The app never requests or stores a seed phrase or private key.

## Receipt protocol

`handoff-receipt`, version `1`, network `solana-devnet`. SHA-256 is 64 lowercase hex characters. The memo is exactly `handoff:v1:sha256:<digest>` in the existing SPL Memo program `MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr`. A confirmed receipt also contains the transaction signature and signing wallet.

The file name and local creation date are convenience metadata. The on-chain record covers the digest, not the filename, local date, project label or any assertion of authorship. Verification reports the transaction's block time separately. The reviewer needs both the file and receipt.

## Current validation and limits

Four automated test groups cover the SHA-256 `abc` vector, a changed byte, receipt validation and chain inspection failures. Browser checks cover creating a sample receipt, exporting and reimporting it, a matching file and an edited file. A live wallet transaction has not yet been tested. The optional `node tests/devnet-smoke.mjs` integration attempt stopped when the devnet faucet returned an internal error. This is an incomplete integration test, not a passing result.

The app supports an injected wallet compatible with `connect()` and `signTransaction()`. Public RPC can be rate-limited. The maximum file size is 100 MB and hashing reads the file into memory. Receipts remain portable JSON files, with no account or shared database. No custom smart contract is necessary for this MVP.

This is a test-network prototype. Devnet can reset. A digest or transaction does not prove authorship, originality, ownership or a teacher's acceptance. A hash of a predictable file can reveal a match to anyone who already has a candidate copy. The app does not provide encryption, storage, identity verification or plagiarism detection.

## Build provenance

The competition requires building with Noah AI. The authenticated Noah workspace currently has zero generation credits and blocks the build. Noah integration and evidence of that workflow remain pending. Do not submit this package as a Noah-built entry until that requirement is actually met.

## References

- [SPL Memo program](https://www.solana-program.com/docs/memo)
- [Solana devnet faucet](https://faucet.solana.com/)
- [Competition requirements](https://superteam.fun/earn/listing/develop-solana-web3-project-mvp-and-pitch-for-ifk-uni-vibeathon)
