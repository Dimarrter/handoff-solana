import {Buffer} from 'buffer';
import {Connection,PublicKey,Transaction,TransactionInstruction} from '@solana/web3.js';
import {sha256,memoFor,MEMO_PROGRAM,validateReceipt,inspectTransaction} from './core.js';
globalThis.Buffer=Buffer;
const $=id=>document.getElementById(id);
const connection=new Connection('https://api.devnet.solana.com','confirmed');
const sampleBytes=new TextEncoder().encode('HandOff sample project\nRevision 1\nThe final report contains 12 pages.\n');
let receipt=null,wallet=null,checkReceipt=null,checkBytes=null,verifyBusy=false;
function tell(message,error=false){$('notice').textContent=message;$('notice').className=error?'error':'';$('notice').hidden=false;clearTimeout(tell.timer);tell.timer=setTimeout(()=>$('notice').hidden=true,9000);}
function tab(name){const create=name==='create';$('create-panel').hidden=!create;$('verify-panel').hidden=create;for(const id of ['create','verify']){$(`${id}-tab`).classList.toggle('active',id===name);$(`${id}-tab`).setAttribute('aria-selected',String(id===name));}}
$('create-tab').onclick=()=>tab('create');$('verify-tab').onclick=()=>tab('verify');
async function makeReceipt(bytes,name){
  const hash=await sha256(bytes);
  return {format:'handoff-receipt',version:1,network:'solana-devnet',status:'local',fileName:name,fileSize:bytes.byteLength,sha256:hash,createdAt:new Date().toISOString()};
}
function render(){
  $('receipt-name').textContent=receipt.fileName;
  $('receipt-meta').textContent=`${receipt.fileSize.toLocaleString()} bytes · ${new Date(receipt.createdAt).toLocaleString('en-GB')}`;
  $('hash').textContent=receipt.sha256;$('file-label').textContent=receipt.fileName;
  const anchored=receipt.status==='anchored';
  $('status').textContent=anchored?'CONFIRMED ON DEVNET':'LOCAL RECEIPT';
  $('record-state').textContent=anchored?'Confirmed transaction':'Local, not on-chain';
  $('anchor').disabled=anchored;$('anchor').textContent=anchored?'Anchored on devnet':'Anchor on devnet';$('download').disabled=false;
  $('chain-info').replaceChildren();$('chain-info').hidden=!anchored;
  if(anchored){const a=document.createElement('a');a.href=`https://explorer.solana.com/tx/${receipt.signature}?cluster=devnet`;a.target='_blank';a.rel='noopener noreferrer';a.textContent='View confirmed transaction ↗';$('chain-info').append(a);}
  $('receipt-note').textContent=anchored?'The file digest is recorded on devnet. Share this JSON with the file so others can verify it.':'This receipt is local. Connect a wallet with devnet SOL to add a public record. Devnet SOL has no monetary value.';
}
async function choose(file){if(!file)return;if(file.size>100*1024*1024){tell('Choose a file smaller than 100 MB.',true);return;}try{receipt=await makeReceipt(await file.arrayBuffer(),file.name);render();}catch(e){tell(e.message,true);}}
$('file').onchange=e=>choose(e.target.files[0]);
for(const event of ['dragover','dragleave','drop'])$('drop').addEventListener(event,e=>{e.preventDefault();$('drop').classList.toggle('drag',event==='dragover');if(event==='drop')choose(e.dataTransfer.files[0]);});
$('sample').onclick=async()=>{receipt=await makeReceipt(sampleBytes,'studio-report.txt');render();tell('Sample loaded. This is a real SHA-256 digest and a local receipt.');};
function provider(){return window.phantom?.solana||window.solana;}
$('wallet').onclick=async()=>{try{const p=provider();if(!p)throw Error('No Solana wallet detected. Open this app in a browser with Phantom or another compatible Solana wallet. Local receipts and file comparison work without a wallet.');const result=await p.connect();wallet=result.publicKey;$('wallet').textContent=wallet.toString().slice(0,4)+'…'+wallet.toString().slice(-4);tell('Wallet connected. This app uses Solana devnet only.');}catch(e){tell(e.message||'Wallet connection cancelled.',true);}};
$('anchor').onclick=async()=>{
  if(!receipt||receipt.status==='anchored')return;
  if(!wallet){tell('Connect a Solana wallet first. You will need devnet SOL for the test transaction.',true);return;}
  const snapshot={...receipt};$('anchor').disabled=true;$('anchor').textContent='Waiting for wallet…';$('file').disabled=true;$('sample').disabled=true;
  try{
    const p=provider();const {blockhash,lastValidBlockHeight}=await connection.getLatestBlockhash('confirmed');
    const tx=new Transaction({feePayer:wallet,recentBlockhash:blockhash}).add(new TransactionInstruction({programId:new PublicKey(MEMO_PROGRAM),keys:[{pubkey:wallet,isSigner:true,isWritable:false}],data:Buffer.from(memoFor(snapshot.sha256),'utf8')}));
    const balance=await connection.getBalance(wallet);if(balance<10000)throw Error('The wallet needs devnet SOL. Get free test SOL from faucet.solana.com, then try again. Do not buy or send mainnet SOL.');
    const signed=await p.signTransaction(tx);$('anchor').textContent='Confirming on devnet…';
    const signature=await connection.sendRawTransaction(signed.serialize());
    const confirmed=await connection.confirmTransaction({signature,blockhash,lastValidBlockHeight},'confirmed');
    if(confirmed.value.err)throw Error('Devnet transaction failed. No anchored receipt was created.');
    const onchain=await connection.getParsedTransaction(signature,{commitment:'confirmed',maxSupportedTransactionVersion:0});
    const candidate={...snapshot,status:'anchored',signature,signer:wallet.toString()};inspectTransaction(candidate,onchain);
    receipt=candidate;render();tell('Confirmed on devnet. Download the updated receipt.');
  }catch(e){tell(e.message||'The transaction was not completed.',true);render();}
  finally{$('file').disabled=false;$('sample').disabled=false;}
};
$('download').onclick=()=>{if(!receipt)return;const blob=new Blob([JSON.stringify(receipt,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='handoff-'+receipt.sha256.slice(0,12)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
function ready(){$('verify').disabled=!checkReceipt||!checkBytes||verifyBusy;}
$('verify-receipt').onchange=async e=>{checkReceipt=null;result('?','Ready for a new check','Choose the receipt and file, then compare their contents.','');ready();const file=e.target.files[0];if(!file)return;try{if(file.size>32768)throw Error('Receipt JSON must be smaller than 32 KB.');checkReceipt=validateReceipt(JSON.parse(await file.text()));tell('Receipt loaded. Choose the file to compare.');}catch(e){tell(e.message,true);}ready();};
$('verify-file').onchange=async e=>{checkBytes=null;result('?','Ready for a new check','The file selection changed. Run the comparison to check this version.','');ready();const file=e.target.files[0];if(!file)return;if(file.size>100*1024*1024){tell('Choose a file smaller than 100 MB.',true);return;}checkBytes=await file.arrayBuffer();ready();};
function result(symbol,title,body,state){const box=$('verify-result');box.replaceChildren();for(const[tag,text,cls]of[['span',symbol,'result-symbol'],['h3',title,''],['p',body,'']]){const e=document.createElement(tag);e.textContent=text;e.className=cls;box.append(e);}box.parentElement.className='verification '+state;}
async function verify(){
  if(!checkReceipt||!checkBytes||verifyBusy)return;verifyBusy=true;ready();
  const current={...checkReceipt},bytes=checkBytes;
  try{
    const digest=await sha256(bytes);
    if(digest!==current.sha256){result('×','File has changed','The file’s contents do not match the fingerprint in this receipt. A different filename does not affect this check.','failure');return;}
    if(current.status==='local'){result('✓','The file matches','The contents match this local receipt. No blockchain record is attached, so HandOff cannot verify when this digest was first recorded.','success');return;}
    result('…','File matches. Checking devnet…','Looking up the transaction independently.','');
    const tx=await connection.getParsedTransaction(current.signature,{commitment:'confirmed',maxSupportedTransactionVersion:0});const proof=inspectTransaction(current,tx);
    const time=proof.blockTime?new Date(proof.blockTime*1000).toUTCString():`slot ${proof.slot}`;
    result('✓','File and chain record match',`The successful memo contains this digest and the stated wallet signed it. Devnet record: ${time}. This does not prove authorship or ownership.`,'success');
  }catch(e){result('!','Chain proof unverified',`The local file matches, but the chain proof could not be verified. ${e.message}`,'failure');}
  finally{verifyBusy=false;ready();}
}
$('verify').onclick=verify;
async function sampleCheck(tampered){checkReceipt=await makeReceipt(sampleBytes,'studio-report.txt');checkBytes=tampered?new TextEncoder().encode('HandOff sample project\nRevision 2\nThe final report contains 14 pages.\n'):sampleBytes;ready();await verify();}
$('verify-sample').onclick=()=>sampleCheck(false);$('tamper-sample').onclick=()=>sampleCheck(true);
