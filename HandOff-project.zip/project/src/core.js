export const MEMO_PROGRAM='MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr';
export const PREFIX='handoff:v1:sha256:';
export async function sha256(bytes){
  const digest=await globalThis.crypto.subtle.digest('SHA-256',bytes);
  return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('');
}
export function memoFor(hash){if(!/^[a-f0-9]{64}$/.test(hash))throw Error('Invalid SHA-256 digest');return PREFIX+hash;}
export function validateReceipt(input){
  if(!input||input.format!=='handoff-receipt'||input.version!==1)throw Error('This is not a HandOff v1 receipt.');
  if(!/^[a-f0-9]{64}$/.test(input.sha256))throw Error('The receipt has an invalid SHA-256 digest.');
  if(input.network!=='solana-devnet')throw Error('Only Solana devnet receipts are supported.');
  if(!['local','anchored'].includes(input.status))throw Error('Invalid receipt status.');
  if(typeof input.fileName!=='string'||input.fileName.length>255||!Number.isSafeInteger(input.fileSize)||input.fileSize<0)throw Error('Invalid file metadata.');
  if(!Number.isFinite(Date.parse(input.createdAt)))throw Error('Invalid receipt date.');
  if(input.status==='anchored'&&(!/^[1-9A-HJ-NP-Za-km-z]{64,90}$/.test(input.signature||'')||!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(input.signer||'')))throw Error('Invalid transaction reference.');
  return {...input};
}
export function inspectTransaction(receipt,tx){
  if(!tx)throw Error('Transaction not found on devnet. Try again later or check the receipt.');
  if(!tx.meta||tx.meta.err)throw Error('The referenced transaction did not succeed.');
  const keys=tx.transaction.message.accountKeys;
  const signed=keys.some(k=>k.signer&&k.pubkey.toString()===receipt.signer);
  const memo=tx.transaction.message.instructions.some(i=>i.programId.toString()===MEMO_PROGRAM&&typeof i.parsed==='string'&&i.parsed===memoFor(receipt.sha256));
  if(!signed||!memo)throw Error('The on-chain memo or signing wallet does not match this receipt.');
  return {slot:tx.slot,blockTime:tx.blockTime};
}
