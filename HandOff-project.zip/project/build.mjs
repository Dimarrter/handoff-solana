import { build } from 'esbuild';
import fs from 'node:fs/promises';
await fs.mkdir('dist', { recursive: true });
await Promise.all(['index.html','style.css'].map(f => fs.copyFile(`src/${f}`,`dist/${f}`)));
await build({ entryPoints:['src/app.js'], bundle:true, outfile:'dist/app.js', platform:'browser', format:'esm', target:'es2022', minify:true, sourcemap:false, define:{'process.env.NODE_ENV':'"production"','global':'globalThis'} });
console.log('Built dist/');
