// Optional integration smoke test. Creates an ephemeral key in memory.
// No private keys or seed phrases are written to disk or logged.
import {Connection,Keypair,Transaction,TransactionInstruction,PublicKey} from '@solana/web3.js';
import {sha256,memoFor,MEMO_PROGRAM,inspectTransaction} from '../src/core.js';
const rpc=new Connection('https://api.devnet.solana.com','confirmed');
const key=Keypair.generate();
const hash=await sha256(new TextEncoder().encode('HandOff devnet integration smoke test v1'));
console.log('Network: Solana devnet. Ephemeral public key:',key.publicKey.toString());
try {
  const airdrop=await rpc.requestAirdrop(key.publicKey,100000000);
  await rpc.confirmTransaction(airdrop,'confirmed');
  const latest=await rpc.getLatestBlockhash();
  const tx=new Transaction({feePayer:key.publicKey,recentBlockhash:latest.blockhash}).add(new TransactionInstruction({programId:new PublicKey(MEMO_PROGRAM),keys:[{pubkey:key.publicKey,isSigner:true,isWritable:false}],data:Buffer.from(memoFor(hash))}));
  tx.sign(key);
  const signature=await rpc.sendRawTransaction(tx.serialize());
  const confirmation=await rpc.confirmTransaction({...latest,signature},'confirmed');
  if(confirmation.value.err)throw Error('Transaction failed.');
  const parsed=await rpc.getParsedTransaction(signature,{maxSupportedTransactionVersion:0});
  const proof=inspectTransaction({sha256:hash,signer:key.publicKey.toString()},parsed);
  console.log(JSON.stringify({result:'PASS',network:'solana-devnet',signature,sha256:hash,signer:key.publicKey.toString(),...proof}));
}catch(e){console.error('Devnet integration test incomplete:',e.message);process.exitCode=1;}
