import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sha256,memoFor,MEMO_PROGRAM,validateReceipt,inspectTransaction} from '../src/core.js';
const bytes=new TextEncoder().encode('abc');
const hash='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad';
const r={format:'handoff-receipt',version:1,network:'solana-devnet',status:'local',fileName:'a.txt',fileSize:3,sha256:hash,createdAt:'2026-10-10T15:00:00.000Z'};
test('SHA-256 agrees with the published abc test vector',async()=>assert.equal(await sha256(bytes),hash));
test('changing one byte changes the fingerprint',async()=>assert.notEqual(await sha256(new TextEncoder().encode('abd')),hash));
test('receipt validates and rejects mainnet, malformed digest and missing anchoring data',()=>{assert.equal(validateReceipt(r).sha256,hash);for(const bad of [{...r,network:'mainnet'},{...r,sha256:'x'},{...r,status:'anchored'},{...r,fileSize:-1}])assert.throws(()=>validateReceipt(bad));});
test('successful matching memo needs the stated signer',()=>{
  const receipt={...r,status:'anchored',signer:'wallet'};
  const tx={slot:1,blockTime:100,meta:{err:null},transaction:{message:{accountKeys:[{pubkey:'wallet',signer:true}],instructions:[{programId:MEMO_PROGRAM,parsed:memoFor(hash)}]}}};
  assert.equal(inspectTransaction(receipt,tx).slot,1);
  assert.throws(()=>inspectTransaction({...receipt,signer:'other'},tx));
  assert.throws(()=>inspectTransaction(receipt,{...tx,meta:{err:{failure:true}}}));
  tx.transaction.message.instructions[0].parsed=memoFor('0'.repeat(64));assert.throws(()=>inspectTransaction(receipt,tx));
  assert.throws(()=>inspectTransaction(receipt,null));
});
